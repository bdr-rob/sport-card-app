"use client";

import React, { useState, useEffect, useMemo } from "react";
import { Search, Filter, TrendingUp, Calculator, Save, Share2, ChevronRight, X, Menu, Star, ArrowUp, ArrowDown, Check, Info, Camera, History, Bookmark, Grid, List } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { motion, AnimatePresence } from "framer-motion";

// Type definitions
interface SportCard {
  id: string;
  player: string;
  year: number;
  set: string;
  cardNumber: string;
  sport: string;
  manufacturer: string;
  ungradedValue: number;
  gradedValues: {
    PSA10: number;
    PSA9: number;
    PSA8: number;
    BGS10: number;
    BGS9_5: number;
    BGS9: number;
  };
  recentSales: number[];
  imageUrl?: string;
}

interface SearchFilters {
  player: string;
  yearFrom: number;
  yearTo: number;
  sport: string;
  manufacturer: string;
  set: string;
}

interface ConditionAssessment {
  centering: number;
  corners: number;
  edges: number;
  surface: number;
}

// Mock data generator
const generateMockCards = (): SportCard[] => {
  const players = ["Michael Jordan", "LeBron James", "Tom Brady", "Patrick Mahomes", "Mike Trout", "Shohei Ohtani"];
  const sports = ["Basketball", "Football", "Baseball"];
  const manufacturers = ["Topps", "Panini", "Upper Deck", "Bowman"];
  const sets = ["Chrome", "Prizm", "Select", "Optic", "Flagship", "Mosaic"];
  
  const cards: SportCard[] = [];
  
  for (let i = 0; i < 50; i++) {
    const ungradedValue = Math.floor(Math.random() * 500) + 50;
    cards.push({
      id: `card-${i}`,
      player: players[Math.floor(Math.random() * players.length)],
      year: 2018 + Math.floor(Math.random() * 6),
      set: sets[Math.floor(Math.random() * sets.length)],
      cardNumber: `#${Math.floor(Math.random() * 300) + 1}`,
      sport: sports[Math.floor(Math.random() * sports.length)],
      manufacturer: manufacturers[Math.floor(Math.random() * manufacturers.length)],
      ungradedValue,
      gradedValues: {
        PSA10: ungradedValue * (3 + Math.random() * 2),
        PSA9: ungradedValue * (1.5 + Math.random()),
        PSA8: ungradedValue * (1.1 + Math.random() * 0.4),
        BGS10: ungradedValue * (3.5 + Math.random() * 2),
        BGS9_5: ungradedValue * (2 + Math.random() * 1.5),
        BGS9: ungradedValue * (1.3 + Math.random() * 0.7),
      },
      recentSales: Array.from({ length: 5 }, () => ungradedValue + Math.floor(Math.random() * 100) - 50),
    });
  }
  
  return cards;
};

export default function SportCardValueApp() {
  // State management
  const [cards] = useState<SportCard[]>(generateMockCards());
  const [searchFilters, setSearchFilters] = useState<SearchFilters>({
    player: "",
    yearFrom: 2018,
    yearTo: 2024,
    sport: "all",
    manufacturer: "all",
    set: "",
  });
  const [selectedCard, setSelectedCard] = useState<SportCard | null>(null);
  const [compareCards, setCompareCards] = useState<SportCard[]>([]);
  const [showFilters, setShowFilters] = useState(false);
  const [viewMode, setViewMode] = useState<"search" | "compare" | "evaluate">("search");
  const [savedSearches, setSavedSearches] = useState<SearchFilters[]>([]);
  const [conditionAssessment, setConditionAssessment] = useState<ConditionAssessment>({
    centering: 50,
    corners: 50,
    edges: 50,
    surface: 50,
  });
  const [gradingService, setGradingService] = useState("PSA");
  const [estimatedGrade, setEstimatedGrade] = useState("9");
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [displayMode, setDisplayMode] = useState<"grid" | "list">("grid");

  // Load saved searches from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("savedSearches");
    if (saved) {
      setSavedSearches(JSON.parse(saved));
    }
  }, []);

  // Filter cards based on search criteria
  const filteredCards = useMemo(() => {
    return cards.filter(card => {
      const playerMatch = card.player.toLowerCase().includes(searchFilters.player.toLowerCase());
      const yearMatch = card.year >= searchFilters.yearFrom && card.year <= searchFilters.yearTo;
      const sportMatch = searchFilters.sport === "all" || card.sport === searchFilters.sport;
      const manufacturerMatch = searchFilters.manufacturer === "all" || card.manufacturer === searchFilters.manufacturer;
      const setMatch = card.set.toLowerCase().includes(searchFilters.set.toLowerCase());
      
      return playerMatch && yearMatch && sportMatch && manufacturerMatch && setMatch;
    });
  }, [cards, searchFilters]);

  // Calculate ROI for grading
  const calculateROI = (card: SportCard, grade: string, service: string) => {
    const gradingCost = service === "PSA" ? 30 : 25;
    const shippingCost = 15;
    const totalCost = gradingCost + shippingCost;
    
    let gradedValue = 0;
    if (service === "PSA") {
      gradedValue = grade === "10" ? card.gradedValues.PSA10 : 
                    grade === "9" ? card.gradedValues.PSA9 : 
                    card.gradedValues.PSA8;
    } else {
      gradedValue = grade === "10" ? card.gradedValues.BGS10 : 
                    grade === "9.5" ? card.gradedValues.BGS9_5 : 
                    card.gradedValues.BGS9;
    }
    
    const profit = gradedValue - card.ungradedValue - totalCost;
    const roiPercentage = ((profit / (card.ungradedValue + totalCost)) * 100).toFixed(1);
    
    return { profit, roiPercentage, gradedValue, totalCost };
  };

  // Calculate condition score
  const calculateConditionScore = () => {
    const average = (conditionAssessment.centering + conditionAssessment.corners + 
                    conditionAssessment.edges + conditionAssessment.surface) / 4;
    
    if (average >= 95) return "10";
    if (average >= 90) return "9.5";
    if (average >= 85) return "9";
    if (average >= 75) return "8";
    return "7";
  };

  // Save search
  const saveSearch = () => {
    const newSavedSearches = [...savedSearches, searchFilters];
    setSavedSearches(newSavedSearches);
    localStorage.setItem("savedSearches", JSON.stringify(newSavedSearches));
  };

  // Add card to comparison
  const addToCompare = (card: SportCard) => {
    if (compareCards.length < 3 && !compareCards.find(c => c.id === card.id)) {
      setCompareCards([...compareCards, card]);
    }
  };

  // Remove card from comparison
  const removeFromCompare = (cardId: string) => {
    setCompareCards(compareCards.filter(c => c.id !== cardId));
  };

  // Header Component
  const Header = () => (
    <header className="bg-white border-b sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setShowMobileMenu(!showMobileMenu)}
              className="lg:hidden"
            >
              <Menu className="h-6 w-6" />
            </button>
            <h1 className="text-xl lg:text-2xl font-bold text-gray-900">CardValue Pro</h1>
          </div>
          
          <nav className="hidden lg:flex items-center space-x-6">
            <button
              onClick={() => setViewMode("search")}
              className={`px-4 py-2 rounded-lg transition-colors ${
                viewMode === "search" ? "bg-blue-100 text-blue-700" : "text-gray-600 hover:text-gray-900"
              }`}
            >
              Search Cards
            </button>
            <button
              onClick={() => setViewMode("compare")}
              className={`px-4 py-2 rounded-lg transition-colors ${
                viewMode === "compare" ? "bg-blue-100 text-blue-700" : "text-gray-600 hover:text-gray-900"
              }`}
            >
              Compare ({compareCards.length})
            </button>
            <button
              onClick={() => setViewMode("evaluate")}
              className={`px-4 py-2 rounded-lg transition-colors ${
                viewMode === "evaluate" ? "bg-blue-100 text-blue-700" : "text-gray-600 hover:text-gray-900"
              }`}
            >
              Evaluate Grading
            </button>
          </nav>
          
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="icon">
              <History className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="icon">
              <Bookmark className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
      
      {/* Mobile Menu */}
      <AnimatePresence>
        {showMobileMenu && (
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: "auto" }}
            exit={{ height: 0 }}
            className="lg:hidden overflow-hidden bg-gray-50 border-t"
          >
            <div className="container mx-auto px-4 py-4 space-y-2">
              <button
                onClick={() => { setViewMode("search"); setShowMobileMenu(false); }}
                className={`w-full text-left px-4 py-2 rounded-lg ${
                  viewMode === "search" ? "bg-blue-100 text-blue-700" : "text-gray-600"
                }`}
              >
                Search Cards
              </button>
              <button
                onClick={() => { setViewMode("compare"); setShowMobileMenu(false); }}
                className={`w-full text-left px-4 py-2 rounded-lg ${
                  viewMode === "compare" ? "bg-blue-100 text-blue-700" : "text-gray-600"
                }`}
              >
                Compare ({compareCards.length})
              </button>
              <button
                onClick={() => { setViewMode("evaluate"); setShowMobileMenu(false); }}
                className={`w-full text-left px-4 py-2 rounded-lg ${
                  viewMode === "evaluate" ? "bg-blue-100 text-blue-700" : "text-gray-600"
                }`}
              >
                Evaluate Grading
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );

  // Search View Component
  const SearchView = () => (
    <div className="space-y-6">
      {/* Search Bar */}
      <Card>
        <CardContent className="p-6">
          <div className="space-y-4">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <Input
                    placeholder="Search by player name..."
                    value={searchFilters.player}
                    onChange={(e) => setSearchFilters({ ...searchFilters, player: e.target.value })}
                    className="pl-10"
                  />
                </div>
              </div>
              <Button
                variant="outline"
                onClick={() => setShowFilters(!showFilters)}
                className="lg:w-auto"
              >
                <Filter className="h-4 w-4 mr-2" />
                Filters
              </Button>
              <Button onClick={saveSearch} variant="outline">
                <Save className="h-4 w-4 mr-2" />
                Save Search
              </Button>
              <div className="flex items-center space-x-2">
                <Button
                  variant={displayMode === "grid" ? "default" : "outline"}
                  size="icon"
                  onClick={() => setDisplayMode("grid")}
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Button
                  variant={displayMode === "list" ? "default" : "outline"}
                  size="icon"
                  onClick={() => setDisplayMode("list")}
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            {/* Advanced Filters */}
            <AnimatePresence>
              {showFilters && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  className="overflow-hidden"
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 pt-4 border-t">
                    <div>
                      <Label>Sport</Label>
                      <Select
                        value={searchFilters.sport}
                        onValueChange={(value) => setSearchFilters({ ...searchFilters, sport: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Sports</SelectItem>
                          <SelectItem value="Basketball">Basketball</SelectItem>
                          <SelectItem value="Football">Football</SelectItem>
                          <SelectItem value="Baseball">Baseball</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label>Manufacturer</Label>
                      <Select
                        value={searchFilters.manufacturer}
                        onValueChange={(value) => setSearchFilters({ ...searchFilters, manufacturer: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Manufacturers</SelectItem>
                          <SelectItem value="Topps">Topps</SelectItem>
                          <SelectItem value="Panini">Panini</SelectItem>
                          <SelectItem value="Upper Deck">Upper Deck</SelectItem>
                          <SelectItem value="Bowman">Bowman</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label>Year From</Label>
                      <Input
                        type="number"
                        value={searchFilters.yearFrom}
                        onChange={(e) => setSearchFilters({ ...searchFilters, yearFrom: parseInt(e.target.value) })}
                        min="1950"
                        max="2024"
                      />
                    </div>
                    
                    <div>
                      <Label>Year To</Label>
                      <Input
                        type="number"
                        value={searchFilters.yearTo}
                        onChange={(e) => setSearchFilters({ ...searchFilters, yearTo: parseInt(e.target.value) })}
                        min="1950"
                        max="2024"
                      />
                    </div>
                    
                    <div className="lg:col-span-4">
                      <Label>Set Name</Label>
                      <Input
                        placeholder="e.g., Chrome, Prizm, Select..."
                        value={searchFilters.set}
                        onChange={(e) => setSearchFilters({ ...searchFilters, set: e.target.value })}
                      />
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </CardContent>
      </Card>
      
      {/* Results Count */}
      <div className="flex items-center justify-between">
        <p className="text-gray-600">Found {filteredCards.length} cards</p>
        <div className="flex items-center space-x-2">
          <span className="text-sm text-gray-500">Sort by:</span>
          <Select defaultValue="value">
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="value">Highest Value</SelectItem>
              <SelectItem value="roi">Best ROI</SelectItem>
              <SelectItem value="recent">Most Recent</SelectItem>
              <SelectItem value="player">Player Name</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      {/* Card Grid/List */}
      {displayMode === "grid" ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredCards.map((card) => (
            <motion.div
              key={card.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardHeader className="pb-3">
                  <div className="aspect-[3/4] bg-gray-100 rounded-lg mb-3 flex items-center justify-center">
                    <div className="text-center p-4">
                      <p className="text-sm text-gray-500">{card.year} {card.manufacturer}</p>
                      <p className="font-semibold">{card.player}</p>
                      <p className="text-xs text-gray-500">{card.set} {card.cardNumber}</p>
                    </div>
                  </div>
                  <CardTitle className="text-lg">{card.player}</CardTitle>
                  <CardDescription>
                    {card.year} {card.manufacturer} {card.set}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Ungraded</span>
                    <span className="font-semibold">${card.ungradedValue}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">PSA 10</span>
                    <span className="font-semibold text-green-600">
                      ${card.gradedValues.PSA10.toFixed(0)}
                      <ArrowUp className="inline h-3 w-3 ml-1" />
                    </span>
                  </div>
                  <div className="pt-3 flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      className="flex-1"
                      onClick={() => setSelectedCard(card)}
                    >
                      Details
                    </Button>
                    <Button
                      size="sm"
                      variant={compareCards.find(c => c.id === card.id) ? "secondary" : "default"}
                      className="flex-1"
                      onClick={() => compareCards.find(c => c.id === card.id) ? removeFromCompare(card.id) : addToCompare(card)}
                    >
                      {compareCards.find(c => c.id === card.id) ? "Remove" : "Compare"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="space-y-2">
          {filteredCards.map((card) => (
            <motion.div
              key={card.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3 }}
            >
              <Card className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-16 h-20 bg-gray-100 rounded flex items-center justify-center">
                        <span className="text-xs text-gray-500">Image</span>
                      </div>
                      <div>
                        <h3 className="font-semibold">{card.player}</h3>
                        <p className="text-sm text-gray-600">
                          {card.year} {card.manufacturer} {card.set} {card.cardNumber}
                        </p>
                        <p className="text-sm text-gray-500">{card.sport}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-6">
                      <div className="text-right">
                        <p className="text-sm text-gray-600">Ungraded</p>
                        <p className="font-semibold">${card.ungradedValue}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-600">PSA 10</p>
                        <p className="font-semibold text-green-600">${card.gradedValues.PSA10.toFixed(0)}</p>
                      </div>
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline" onClick={() => setSelectedCard(card)}>
                          Details
                        </Button>
                        <Button
                          size="sm"
                          variant={compareCards.find(c => c.id === card.id) ? "secondary" : "default"}
                          onClick={() => compareCards.find(c => c.id === card.id) ? removeFromCompare(card.id) : addToCompare(card)}
                        >
                          {compareCards.find(c => c.id === card.id) ? "Remove" : "Compare"}
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );

  // Compare View Component
  const CompareView = () => (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Card Comparison</CardTitle>
          <CardDescription>
            Compare up to 3 cards side by side. Add cards from the search results.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {compareCards.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500 mb-4">No cards selected for comparison</p>
              <Button onClick={() => setViewMode("search")}>
                Search Cards
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 min-w-[768px]">
                {compareCards.map((card) => (
                  <Card key={card.id} className="relative">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="absolute top-2 right-2"
                      onClick={() => removeFromCompare(card.id)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                    <CardHeader>
                      <div className="aspect-[3/4] bg-gray-100 rounded-lg mb-3 flex items-center justify-center">
                        <div className="text-center p-4">
                          <p className="text-sm text-gray-500">{card.year} {card.manufacturer}</p>
                          <p className="font-semibold">{card.player}</p>
                          <p className="text-xs text-gray-500">{card.set}</p>
                        </div>
                      </div>
                      <CardTitle className="text-lg">{card.player}</CardTitle>
                      <CardDescription>
                        {card.year} {card.manufacturer} {card.set} {card.cardNumber}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <h4 className="font-semibold text-sm">Current Values</h4>
                        <div className="space-y-1">
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-600">Ungraded</span>
                            <span className="font-medium">${card.ungradedValue}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <h4 className="font-semibold text-sm">PSA Grades</h4>
                        <div className="space-y-1">
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-600">PSA 10</span>
                            <span className="font-medium text-green-600">
                              ${card.gradedValues.PSA10.toFixed(0)}
                              <span className="text-xs ml-1">
                                (+{((card.gradedValues.PSA10 / card.ungradedValue - 1) * 100).toFixed(0)}%)
                              </span>
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-600">PSA 9</span>
                            <span className="font-medium">
                              ${card.gradedValues.PSA9.toFixed(0)}
                              <span className="text-xs ml-1 text-gray-500">
                                (+{((card.gradedValues.PSA9 / card.ungradedValue - 1) * 100).toFixed(0)}%)
                              </span>
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-600">PSA 8</span>
                            <span className="font-medium">
                              ${card.gradedValues.PSA8.toFixed(0)}
                              <span className="text-xs ml-1 text-gray-500">
                                (+{((card.gradedValues.PSA8 / card.ungradedValue - 1) * 100).toFixed(0)}%)
                              </span>
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <h4 className="font-semibold text-sm">BGS Grades</h4>
                        <div className="space-y-1">
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-600">BGS 10</span>
                            <span className="font-medium text-green-600">
                              ${card.gradedValues.BGS10.toFixed(0)}
                              <span className="text-xs ml-1">
                                (+{((card.gradedValues.BGS10 / card.ungradedValue - 1) * 100).toFixed(0)}%)
                              </span>
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-600">BGS 9.5</span>
                            <span className="font-medium">
                              ${card.gradedValues.BGS9_5.toFixed(0)}
                              <span className="text-xs ml-1 text-gray-500">
                                (+{((card.gradedValues.BGS9_5 / card.ungradedValue - 1) * 100).toFixed(0)}%)
                              </span>
                            </span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm text-gray-600">BGS 9</span>
                            <span className="font-medium">
                              ${card.gradedValues.BGS9.toFixed(0)}
                              <span className="text-xs ml-1 text-gray-500">
                                (+{((card.gradedValues.BGS9 / card.ungradedValue - 1) * 100).toFixed(0)}%)
                              </span>
                            </span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="pt-4 border-t">
                        <h4 className="font-semibold text-sm mb-2">ROI Analysis</h4>
                        <div className="space-y-2">
                          {["10", "9", "8"].map((grade) => {
                            const roi = calculateROI(card, grade, "PSA");
                            return (
                              <div key={grade} className="text-sm">
                                <div className="flex justify-between items-center">
                                  <span className="text-gray-600">PSA {grade}</span>
                                  <span className={roi.profit > 0 ? "text-green-600" : "text-red-600"}>
                                    {roi.profit > 0 ? "+" : ""}{roi.roiPercentage}%
                                  </span>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );

  // Evaluate View Component
  const EvaluateView = () => {
    const estimatedGradeValue = calculateConditionScore();
    const selectedCardForEval = selectedCard || filteredCards[0];
    const roiData = selectedCardForEval ? calculateROI(selectedCardForEval, estimatedGradeValue, gradingService) : null;

    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Grading Evaluation Tool</CardTitle>
            <CardDescription>
              Assess your card's condition and get grading recommendations
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Card Selection */}
            <div>
              <Label>Select Card to Evaluate</Label>
              <Select
                value={selectedCardForEval?.id}
                onValueChange={(value) => setSelectedCard(cards.find(c => c.id === value) || null)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Choose a card from your search results" />
                </SelectTrigger>
                <SelectContent>
                  {filteredCards.slice(0, 10).map((card) => (
                    <SelectItem key={card.id} value={card.id}>
                      {card.player} - {card.year} {card.set}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedCardForEval && (
              <>
                {/* Condition Assessment */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-semibold">Condition Assessment</h3>
                    
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between mb-1">
                          <Label>Centering</Label>
                          <span className="text-sm text-gray-600">{conditionAssessment.centering}%</span>
                        </div>
                        <input
                          type="range"
                          min="0"
                          max="100"
                          value={conditionAssessment.centering}
                          onChange={(e) => setConditionAssessment({
                            ...conditionAssessment,
                            centering: parseInt(e.target.value)
                          })}
                          className="w-full"
                        